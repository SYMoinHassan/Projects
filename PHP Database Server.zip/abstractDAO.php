<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: abstractDAO.php
-->
<?php
abstract class AbstractDAO {
    private $connection;
    function __construct($host, $username, $password, $db, $port = 3306) {
        $this->connection = new mysqli($host, $username, $password, $db, $port);
        if ($this->connection->connect_errno) {
            echo "Failed to connect";
            exit();
        }
    }
    // The following abstract methods define the common CRUD operations to be implemented by concrete DAO classes
    abstract function readAll();
    abstract function get($id);
    abstract function create($entity);
    abstract function update($entity);
    abstract function delete($id);
    protected function getConnection() {
        return $this->connection;
    }
}

?>