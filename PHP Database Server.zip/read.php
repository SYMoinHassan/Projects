<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: read.php
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entity Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="css/read.css">
</head>
<body>
    <?php   
        require_once("entityDAO.php");
        require_once("entity.php");
        $id=$_GET["id"];
        $dao = new EntityDAO();
        $entity = $dao->get($id);
    ?>
    <div class="entity">
        <div class="row">
            <div class="col">
                <p class="entity-id">ID: <?php echo $entity->id; ?></p>
                <p class="entity-number">Number: <?php echo $entity->number; ?></p>
                <p class="entity-text">Text: <?php echo $entity->text; ?></p>
                <p class="entity-date">Date: <?php echo $entity->date; ?></p>
            </div>
            <?php if ($entity->image != null): ?>
            <div class="col text-end">
                <img class="entity-image" src="<?php echo $entity->image; ?>" />
            </div>
            <?php endif; ?>
        </div>
    </div>
    <form class="form" action="index.php">
        <input class="button" type="submit" value="Back"/>
    </form>
</body>
</html>
