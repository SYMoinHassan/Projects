<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: create.php
-->
<?php
require_once("entityDAO.php");
require_once("entity.php");

if (isset($_POST["submit"])) {
    $dao = new entityDAO();
    $imageSrc = null;
    //check if an image has been uploaded
    if ($_FILES["image"]["size"] != 0) {
        $image = $_FILES["image"];
        $imageSrc = $dao->imagesPath.$image["name"];
        move_uploaded_file($image["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/".$imageSrc);
        $imageSrc = "/".$imageSrc;
    }
    //create a new entity 
    $entity = new entity(null, $_POST["number"], $_POST["text"], $_POST["date"], $imageSrc);
    if ($dao->create($entity)) {
        //if entity is created successfully, redirect to the index page
        echo $imageSrc; 
        header('Location:'.'index.php');
        die();
    }
    //if there was an error creating the entity, print the error message
    echo $dao->getError();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Entity</title>
  <link rel="stylesheet" href="css/create.css">
</head>
<body>
  <div class="container">
    <h1 id="create-entity-title">Create Entity</h1>
    <form id="create-entity-form" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="number-input" class="form-label">Number:</label>
        <input type="number" id="number-input" class="form-control" name="number" min="0" max="100" value="0" required>
      </div>
      <div class="form-group">
        <label for="text-input" class="form-label">Text:</label>
        <input type="text" id="text-input" class="form-control" name="text" placeholder="Enter some text" required>
      </div>
      <div class="form-group">
        <label for="date-input" class="form-label">Date:</label>
        <input type="date" id="date-input" class="form-control" name="date" required>
      </div>
      <div class="form-group">
        <label for="image-input" class="form-label">Image:</label>
        <input type="file" id="image-input" class="form-control" name="image" accept="image/*">
      </div>
      <div class="form-group">
        <input type="submit" id="submit-button" class="btn btn-primary" name="submit" value="Submit">
      </div>
    </form>
  </div>
</body>
</html>
