<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: entityDAO.php
-->
<?php
// Require necessary files
require_once("abstractDAO.php");
require_once("entity.php");

// Class EntityDAO, which extends AbstractDAO
class EntityDAO extends AbstractDAO {
    // Set the path for images and initialize class variables
    public $imagesPath = "images/";
    private $connection;
    private $error = null;

    // Constructor, which calls parent constructor and sets up the database connection
    function __construct() {
        parent::__construct("localhost", "root", "", "Assignment2_DB", 3366);
    }

    // Function to read all entities from the database
    function readAll(){
        $connection = $this->getConnection();
        $entities = [];

        // Query the database for all entities
        if($result = $connection -> query("SELECT * FROM Entities")) {
            // Loop through each row and create a new Entity object
            while ($row = $result->fetch_assoc()) {
                $entities[] = new entity(
                    $row["ID"],
                    $row["Number"],
                    $row["Text"],
                    $row["Date"],
                    $row["Image"]
                );
            }
        }
        else {
            return null;
        }
        // Return an array of Entity objects
        return $entities;
    }

    // Function to get a single entity by ID from the database
    function get($id){
        $connection = $this->getConnection();

        // Query the database for the entity with the given ID
        $result = $connection -> query("SELECT * FROM Entities WHERE ID = $id");

        // If a row is found, create a new Entity object and return it
        if ($row = $result->fetch_assoc())
            return new entity(
                $row["ID"],
                $row["Number"],
                $row["Text"],
                $row["Date"],
                $row["Image"]
            );
        else {
            return null;
        }
    }

    // Function to create a new entity in the database
    function create($entity){
        $connection = $this->getConnection();
        $query = 'INSERT INTO Entities (Number, Text, Date, Image) VALUES (?, ?, ?, ?)';
        $stmt = $connection->prepare($query);

        // Check if the entity is valid and if the statement was prepared successfully
        if($this->validateEntity($entity) && $stmt){
            // Bind parameters and execute the statement
            $stmt->bind_param('isss',
            $entity->number,
            $entity->text,
            $entity->date,
            $entity->image);
            $stmt->execute();
            // Return true if the statement was executed successfully
            return true;
        }

        // Return false if the statement was not executed successfully
        return false;
    }

    // Function to update an existing entity in the database
    function update($entity){
        $connection = $this->getConnection();
        $query = 'UPDATE Entities SET Number = ?, Text = ?, Date = ?, Image = ? WHERE ID = ?';
        $stmt = $connection->prepare($query);

        // Check if the entity is valid and if the statement was prepared successfully
        if($this-> validateEntity($entity) && $stmt){
            // Bind parameters and execute the statement
            $stmt->bind_param('isssi',
            $entity->number,
            $entity->text,
            $entity->date,
            $entity->image,
            $entity->id);
            $stmt->execute();
            // Return true if the statement was executed successfully
            return true;
        }

        // Return false if the statement was not executed successfully
        return false;
    }
    
    // This function deletes an entity with the given ID from the database.
    function delete($id){
        $connection = $this->getConnection();
        $result = $connection -> query("DELETE FROM Entities WHERE ID = $id");

        // Check if there was an error while deleting the entity.
        if ($this->connection->errno) {
            echo $connection->error;
            return false;
        }

        return true;
    }

    // This function validates the given entity.
    function validateEntity($entity) {
        $valid = true;

        // Check if the entity's number property is null.
        if ($entity->number == null) {
            $this->error .= "You must enter a number. <br>";
            $valid = false;
        }

        // Check if the entity's text property is null.
        if ($entity->text == null) {
            $this->error .= "You must enter some text. <br>";
            $valid = false;
        }

        // Check if the entity's date property is null.
        if ($entity->date == null) {
            $this->error .= "You must enter a valid date. <br>";
            $valid = false;
        }

        // Check if the entity's date is between 1950-01-01 and today.
        $date = strtotime($entity->date);
        if ($date < strtotime("1950-01-01") || $date > strtotime("today")) {
            $this->error .= "Date must be with 1950 to present. <br>";
            $valid = false;
        }

        // Check if the length of the entity's text property is between 5 and 200 characters.
        $testLength = strlen($entity->text);
        if($testLength < 5 || $testLength > 200) {
            $this->error .= "You must enter a minimum of 5 characters and a maximum of 200 <br>";
            $valid = false;
        }

        // Check if the entity's number property is between 0 and 100.
        if ($entity->number < 0 || $entity->number > 100){
            $this->error .= "Number must be between 0 to 100 <br>";
            $valid = false;
        }

        return $valid;
    }

    // This function returns the error message that was generated during the entity validation process.
    function getError() {
        return $this->error;
    }
}
?>