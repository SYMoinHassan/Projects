<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: update.php
-->
<?php
require_once("entityDAO.php");
require_once("entity.php");
$id = null;
if (isset($_REQUEST["id"]))
    $id = $_REQUEST["id"];
$dao = new entityDAO();
$entity = $dao->get($id);
// If the form has been submitted, update the entity with the new data
if (isset($_POST["submit"])) {
    // Get the current image path
    $imageSrc = $entity->image;
    // If a new image has been uploaded, save it to the database and update the image path
    if ($_FILES["image"]["size"] != 0) {
        $image = $_FILES["image"];
        $imageSrc = $dao->imagesPath.$image["name"];
        move_uploaded_file($image["tmp_name"], $_SERVER['DOCUMENT_ROOT']."/".$imageSrc);
        $imageSrc = "/".$imageSrc;
    }
    // Create a new entity object with the submitted form data and update it in the database
    $entity = new entity($id, $_POST["number"], $_POST["text"], $_POST["date"], $imageSrc);
    if ($dao->update($entity)) {
        // If successful, redirect to the index page
        header('Location:'.'index.php');
        die();
    }
    // else recieves an error
    echo $dao->getError();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Entity</title>
    <link rel="stylesheet" href="css/update.css">
</head>
<body>
    <div class="container">
        <h1 class="title">Update Entity</h1>
        <form method="post" enctype="multipart/form-data" class="update-form">
            <div class="group">
                <label for="number" class="label">Number:</label>
                <input id="number-input" name="number" type="number" min="0" max="100" value="<?php echo $entity->number; ?>" required class="input">
            </div>
            <div class="group">
                <label for="text" class="label">Text:</label>
                <input id="text-input" name="text" type="text" placeholder="Enter some text" value="<?php echo $entity->text; ?>" required class="input">
            </div>
            <div class="group">
                <label for="date" class="label">Date:</label>
                <input id="date-input" name="date" type="date" value="<?php echo $entity->date; ?>" required class="input">
            </div>
            <div class="group">
                <label for="image" class="label">Image:</label>
                <input id="image-input" name="image" type="file" accept="image/*" class="input">
            </div>
            <div class="group">
                <input id="submit-button" name="submit" type="submit" value="Submit" class="submit-button">
            </div>
        </form>
    </div>
</body>
</html>
