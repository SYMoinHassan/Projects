<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: index.php
-->
<?php 
require_once("entityDAO.php");
$dao = new EntityDAO();
// call the readAll() function of the EntityDAO object to get all entities
$entities = $dao->readAll();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <header id="head"><h1>PHP DATABASE</h1></header>
    <div class="table-container">
        <table> 
            <tr>
                <th>ID</th>
                <th>Number</th>
                <th>Text</th>
                <th>Date</th>
                <th>Options</th>
            </tr>
            <?php
                foreach($entities as $entity){
                    echo "<tr class='row'>";
                        echo "<td>$entity->id</td>";
                        echo "<td>$entity->number</td>";
                        echo "<td>$entity->text</td>";
                        echo "<td>$entity->date</td>";
                        echo "<td class='options'>";
                            echo "<a href='read.php?id=$entity->id' class='view-link'>view</a>";
                            echo "<a href='update.php?id=$entity->id' class='update-link'>update</a>";
                            echo "<a href='delete.php?id=$entity->id' class='delete-link'>delete</a>";
                        echo "</td>";
                    echo "</tr>";
                }
                echo "<tr>";
                echo "<td colspan='5' class='options'>";
                    echo "<a href='create.php' class='create-link'>+</a>";
                echo "</td>";
                echo "</tr>";
            ?>
        </table>
    </div>
</body>
</html>