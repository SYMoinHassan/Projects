<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: delete.php
-->
<?php
    require_once("entityDAO.php");
    require_once("entity.php");
    $id = $_GET["id"];
    $dao = new EntityDAO();
    // Call the delete() method of the EntityDAO object to delete the entity with the given ID
    $entity = $dao->delete($id);
    // Redirect the user to the index.php page after the entity has been deleted
    header('Location:'.'index.php');
    // Terminate the current script
    die();
?>