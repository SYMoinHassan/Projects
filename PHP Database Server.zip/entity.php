<!--
Name: Syed Moinuddin Hassan
Date: 4/9/2023
Section: CST 8285 section 311
Lab: Assignment 2
File: entity.php
-->
<?php
class entity{    
    // Class properties
    public $id;
    public $number;
    public $text;
    public $date;
    public $image;

    // Class constructor
    function __construct($id, $number, $text, $date, $image){
        // Set class properties with values passed in constructor
        $this-> id = $id;
        $this-> number = $number;
        $this-> text = $text;
        $this-> date = $date;
        $this-> image = $image;
    }
}
?>
